This folder exists as a place holder for the core Java code.  During the
Maven (Tycho) build, the source for the generator will be copied into
this folder.  We do this so we can generate a source bundle in Eclipse.
