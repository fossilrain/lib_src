/**
 * Utility classes for Mapper package.
 */
package com.fasterxml.jackson.databind.util;
